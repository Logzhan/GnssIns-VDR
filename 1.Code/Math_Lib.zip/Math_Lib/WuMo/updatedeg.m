function qb = updatedeg(qa,xdeg,ydeg,zdeg)
qb = qupdate(qa,[xdeg;ydeg;zdeg]*pi/180);
end