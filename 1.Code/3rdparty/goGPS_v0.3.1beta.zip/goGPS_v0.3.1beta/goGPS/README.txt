/*****************************************************************\
*                            .88888.   888888ba  .d88888b         *
*                           d8'   `88  88    `8b 88.    "'        *
*         .d8888b. .d8888b. 88        a88aaaa8P' `Y88888b.        *
*         88'  `88 88'  `88 88   YP88  88              `8b        *
*         88.  .88 88.  .88 Y8.   .88  88        d8'   .8P        *
*         `8888P88 `88888P'  `88888'   dP         Y88888P         *
*              .88                                                *
*          d8888P                                                 *
\*****************************************************************/

   v0.3.1beta

1. Introduction
   ============
   goGPS is a software package designed to perform GPS navigation
   with low cost receivers, either in post-processing or real-time.
   It is developed in MATLAB and it is aimed at providing a tool
   useful for studying GPS navigation, implementing and testing new
   algorithms and interacting in general with GPS-related aspects.

2. Requirements
   ============
   goGPS has been developed and tested in MATLAB 7.6+ environments,
   on both Windows and UNIX. The following elements are needed
   in order to use goGPS:

   - a computer with Windows or a UNIX-based operating system
   - a MATLAB 7.6+ installation

   For post-processing tasks:
   - RINEX observation file for the roving receiver
   - RINEX observation file for the master station
   - RINEX navigation file
     (RINEX files must have epochs in common)
     (goGPS binary data saved during a real-time session
     can be used instead of RINEX files)

   For real-time tasks:
   - 'Instrument Control Toolbox' installed on MATLAB
   - GPS receiver providing raw data on a COM port (currently
     u-blox UBX, Fastrax IT03 and SkyTraq binary protocols are
     supported) with their own drivers installed
   - GPS permanent station(s) broadcasting raw data in RTCM 3.x
     format through NTRIP protocol (at least '1002' or '1004'
     messages)

   NOTE 1: plotting on Google Earth requires it to be installed;
           if plotting error ellipses on Google Earth produces odd
           output on Windows, please switch Google Earth rendering
           engine to DirectX.
		   
   NOTE 2: if you experience problems using the graphical user
           interface under UNIX systems (Linux or Mac), please try
           disabling the UNIX GUI (comment lines 70 and 75-80 in 
           goGPS.m), leaving only the WINDOWS GUI enabled.
           GUIs can be modified using the MATLAB GUIDE tool.
