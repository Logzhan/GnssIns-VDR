#define _CRT_SECURE_NO_WARNINGS
#include "navi.h"

#include <stdio.h>
#include <stdlib.h>

void instance()
{
	int k;
	int L = 100000;
	FILE* fp;
	FILE* fpin;
	MAT ou;
	double datain[12];
	char fin[1000];


	para();//���ò���
	dTins = 0.004;
	//���ó�ֵ����̬���ٶȡ�λ��
	qa = setoula(-143.26, 75.69, 12.2);
	tspeed.num[0][0] = (-37.8472);
	tspeed.num[1][0] = (-50.5556);
	tspeed.num[2][0] = 0.0694;
	tpos.num[0][0] = 0.657102175971747;
	tpos.num[1][0] = 1.895330468487405;
	tpos.num[2][0] = 3765;


	fpin = fopen("datain.txt", "r");//��������
	fp = fopen("dataout.txt", "w");//�������



	for (k = 1; k <= L; k++)
	{
		if (fgets(fin, 1000, fpin) <= 0)
		{
			break;
		}
		sscanf(fin, "%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf", &datain[0], &datain[1], &datain[2], &datain[3], &datain[4], &datain[5], &datain[6], &datain[7], &datain[8], &datain[9], &datain[10], &datain[11]);


		ins_gyroacc(datain[0], datain[1], datain[2], datain[3], datain[4], datain[5]);//���Ե���
		stateupdate();//״̬����

		if ((k % 20) == 0)//��ϵ���
		{
			sat(datain[6], datain[7], datain[8], datain[9], datain[10], datain[11]);
		}


		//��¼����
		ou = getoula(qa);
		fprintf(fp, "%12.6lf,%12.6lf,%12.6lf", ou.num[0][0], ou.num[1][0], ou.num[2][0]);
		fprintf(fp, "%12.6lf,%12.6lf,%12.6lf", tspeed.num[0][0], tspeed.num[1][0], tspeed.num[2][0]);
		fprintf(fp, "%18.9lf,%18.9lf,%12.6lf\n", tpos.num[0][0], tpos.num[1][0], tpos.num[2][0]);


	}

	fclose(fpin);
	fclose(fp);

}


int main()
{
	instance();
	return 0;
}