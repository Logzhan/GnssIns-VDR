function yaw=yaw_angle(sat,type,opt,beta,mu) %#ok

yaw=yaw_nominal(beta,mu);

return