function t=timediff(t1,t2)

t=t1.time-t2.time+t1.sec-t2.sec;

return

