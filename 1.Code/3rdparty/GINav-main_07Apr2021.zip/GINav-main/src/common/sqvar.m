function var=sqvar(covar)

if covar<0
    var=-sqrt(-covar);
else
    var=sqrt(covar);
end

return

