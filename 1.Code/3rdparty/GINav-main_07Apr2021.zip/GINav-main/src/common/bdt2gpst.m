function t=bdt2gpst(t0)

t=timeadd(t0,14);
return;