//
// Created by Lenovo on 2021/8/13.
//

#ifndef IMU_GPS_EKF_CPP_INSEKFFLITER_H
#define IMU_GPS_EKF_CPP_INSEKFFLITER_H
#include <Eigen/Dense>
#include <vector>
typedef Eigen::Matrix<double, 3,1> MVec3;
class INSEKFfliter {
public:
    INSEKFfliter(Eigen::Matrix<double, 4,1> initialAtt_, MVec3 initialPos_, MVec3 initialVel_);
    void predict(const MVec3& accelData, const MVec3& gyroData, double dt);
    void fusegps(MVec3 lla, double dt);
    MVec3 getpos();
private:
    void IMUstateTranTcn(MVec3 accelMeas, MVec3 gyroMeas, double dt);
    Eigen::Matrix<double, 16,16> IMUstateTransitionJacobianFcn(MVec3 accelMeas, MVec3 gyroMeas, double dt);
    Eigen::Matrix<double, 16,12> IMUnoiseJacobianFcn(Eigen::Matrix<double, 16,1>& x, double dt);
    Eigen::Matrix<double, 12,12> IMUnoiseCovariance();
    void predictCovEqnFcn(Eigen::Matrix<double, 16,16>& F,Eigen::Matrix<double, 12,12>& U, Eigen::Matrix<double, 16,12>& G);

    Eigen::Matrix<double, 3,1> GPSPositionmeasurementFcn(Eigen::Matrix<double, 16,1>& x);
    Eigen::Matrix<double, 3,16> GPSPositionmeasurementJacobianFcn(Eigen::Matrix<double, 16,1>& x);
    MVec3 lla2enu(double lon, double lat);
    void correctEqnFcn(Eigen::Matrix<double, 3,1>& h, Eigen::Matrix<double, 3,16>& H, const MVec3& pos, Eigen::Matrix<double, 3,3>& R);
private:
    Eigen::Matrix<double, 4,1> initialAtt;
    MVec3 initialPos;
    MVec3 initialVel;
    Eigen::Matrix<double, 16,1> State;
    Eigen::Matrix<double, 16,16> StateCovariance;
    double accelBiasDecayFactor = 0.9999;
    double gyroBiasDecayFactor  = 0.999;
    double Rpos = 1;
    double GyroscopeNoise = 4e-6;
    double GyroscopeBiasNoise = 4e-14;
    double AccelerometerNoise = 4.8e-2;
    double AccelerometerBiasNoise = 4e-14;
};


#endif //IMU_GPS_EKF_CPP_INSEKFFLITER_H
