#include "INSEKFfliter.h"
#include <iostream>
#include <fstream>

Eigen::Matrix<double, 4,1> initialAtt;/* NOLINT */
Eigen::Matrix<double, 3,1> initialPos;/* NOLINT */
Eigen::Matrix<double, 3,1> initialVel;/* NOLINT */
std::vector<MVec3> accelDatas;
std::vector<MVec3> gyroDatas;
std::vector<MVec3> llas;
std::vector<MVec3> truePositions;
std::vector<MVec3> estposs;
enum ReadState
{
    IDLE,
    READ_initialAtt,
    READ_initialPos,
    READ_initialVel,
    READ_accelDatas,
    READ_gyroDatas,
    READ_llas,
    READ_truePositions
};
void ReadDataFromTxt(const std::string& filename)
{
    std::ifstream textfile(filename);
    std::string line;
    ReadState state = IDLE;
    MVec3 tmpData;
    while (std::getline(textfile, line)) {
        int pos;
        pos = line.find("initialAtt");
        if(pos != std::string::npos) {
            state = READ_initialAtt;
            std::getline(textfile, line);
        }

        pos = line.find("initialPos");
        if(pos != std::string::npos) {
            state = READ_initialPos;
            std::getline(textfile, line);
        }

        pos = line.find("initialVel");
        if(pos != std::string::npos) {
            state = READ_initialVel;
            std::getline(textfile, line);
        }

        pos = line.find("accelDatas");
        if(pos != std::string::npos) {
            state = READ_accelDatas;
            std::getline(textfile, line);
        }

        pos = line.find("gyroDatas");
        if(pos != std::string::npos) {
            state = READ_gyroDatas;
            std::getline(textfile, line);
        }

        pos = line.find("llas");
        if(pos != std::string::npos) {
            state = READ_llas;
            std::getline(textfile, line);
        }

        pos = line.find("truePositions");
        if(pos != std::string::npos) {
            state = READ_truePositions;
            std::getline(textfile, line);
        }
        std::stringstream linstream(line);
        switch(state)
        {
            case READ_initialAtt:
                linstream>>initialAtt(0);
                linstream>>initialAtt(1);
                linstream>>initialAtt(2);
                linstream>>initialAtt(3);
                break;
            case READ_initialPos:
                linstream>>initialPos(0);
                linstream>>initialPos(1);
                linstream>>initialPos(2);
                break;
            case READ_initialVel:
                linstream>>initialVel(0);
                linstream>>initialVel(1);
                linstream>>initialVel(2);
                break;
            case READ_accelDatas:
                linstream>>tmpData(0);
                linstream>>tmpData(1);
                linstream>>tmpData(2);
                accelDatas.emplace_back(tmpData);
                break;
            case READ_gyroDatas:
                linstream>>tmpData(0);
                linstream>>tmpData(1);
                linstream>>tmpData(2);
                gyroDatas.emplace_back(tmpData);
                break;
            case READ_llas:
                linstream>>tmpData(0);
                linstream>>tmpData(1);
                linstream>>tmpData(2);
                llas.emplace_back(tmpData);
                break;
            case READ_truePositions:
                //std::cout<<linstream.str()<<std::endl;
                linstream>>tmpData(0);
                linstream>>tmpData(1);
                linstream>>tmpData(2);
                //std::cout<<tmpData<<std::endl;
                truePositions.emplace_back(tmpData);
                break;
            case IDLE:
                break;
        }
    }
}

int main() {
    std::string filename = ".\\trajData1.txt";
    std::cout << "IMU GPS EKF" << std::endl;
    ReadDataFromTxt(filename);
    std::cout<<"TruePositions size is "<<truePositions.size()<<std::endl;
    int cntIMU = 0;
    int cntGPS = 0;
    INSEKFfliter insekFfliter(initialAtt, initialPos, initialVel);
    double dt = 0.01;
    for(int i = 0; i < accelDatas.size()/10; ++i)
    {
        for(int j = 0; j < 10; ++j)
        {
            MVec3 accelData = accelDatas[cntIMU];
            MVec3 gyroData  = gyroDatas[cntIMU];
            cntIMU++;
            insekFfliter.predict(accelData, gyroData, dt);
            estposs.emplace_back(insekFfliter.getpos());
        }
        MVec3 lla = llas[cntGPS];
        cntGPS++;
        insekFfliter.fusegps(lla, dt);
        estposs.emplace_back(insekFfliter.getpos());
    }
    for(int i = 0; i < std::min(truePositions.size(), estposs.size()); ++i)
    {
        auto truePosition = truePositions[i];
        auto estpos       = estposs[i];
        std::cout<< truePosition[0]<<","<<truePosition[1]<<","<<estpos[0]<<","<<estpos[1]<<std::endl;
    }
    return 0;
}
