function F = IMUstateTransitionJacobianFcn(x, dt, accelMeas, gyroMeas, accelBiasDecayFactor, gyroBiasDecayFactor)
            % STATETRANSITIONJACOBIANFCN Jacobian of process equations
            %   Compute the Jacobian matrix F of the state transition function f(x)
            %   with respect to state x.
            
            q0 = x(1);
            q1 = x(2);
            q2 = x(3);
            q3 = x(4);
            gbX = x(5);
            gbY = x(6);
            gbZ = x(7);
            pn = x(8); %#ok<NASGU>
            pe = x(9); %#ok<NASGU>
            pd = x(10); %#ok<NASGU>
            vn = x(11); %#ok<NASGU>
            ve = x(12); %#ok<NASGU>
            vd = x(13); %#ok<NASGU>
            abX = x(14);
            abY = x(15);
            abZ = x(16);
            
            amX = accelMeas(1);
            amY = accelMeas(2);
            amZ = accelMeas(3);
            gmX = gyroMeas(1);
            gmY = gyroMeas(2);
            gmZ = gyroMeas(3);
            
            lambdaAccel = 1-accelBiasDecayFactor;
            lambdaGyro = 1-gyroBiasDecayFactor;
            
            % The matrix here is the Jacobian of the equations in stateTransitionFcn().
            % The orientation quaternion update portion uses an approximation of
            % the quaternion incremental rotation update equation. The state
            % equation of the quaternion update (ignoring positive angle and
            % normalization requirements) is
            %   q_next = q_current * q_increment
            %
            %   where q_increment = quaternion( deltaAngle, 'rotvec')
            %
            % A quaternion is computed from a rotation vector as :
            %   q = (cos(ang)^2 + sin(ang)^2 *( ax(1) *i + ax(2)*j + ax(3)*k)
            % for axis 1-by-3 axis 'ax' and angle of rotation 'ang'.
            %
            % Using a small angle approximation,
            %   cos(ang)^2 == 0
            % Using the Maclaurin expansion and truncating after the first term:
            %   sin(ang)^2 * ax(n) == 1/2 * ax(n)
            % So the rotation vector to quaternion approximation used in the
            % Jacobian calculation below is:
            %   q_increment = quaternion(0, ax(1)/2, ax(2)/2, ax(3)/2)
            F = ...
                [
                1,                                           dt*(gbX/2 - gmX/2),                                           dt*(gbY/2 - gmY/2),                                           dt*(gbZ/2 - gmZ/2),         (dt*q1)/2,         (dt*q2)/2,         (dt*q3)/2, 0, 0, 0,  0,  0,  0,                              0,                              0,                              0;
                -dt*(gbX/2 - gmX/2),                                                            1,                                          -dt*(gbZ/2 - gmZ/2),                                           dt*(gbY/2 - gmY/2),        -(dt*q0)/2,         (dt*q3)/2,        -(dt*q2)/2, 0, 0, 0,  0,  0,  0,                              0,                              0,                              0;
                -dt*(gbY/2 - gmY/2),                                           dt*(gbZ/2 - gmZ/2),                                                            1,                                          -dt*(gbX/2 - gmX/2),        -(dt*q3)/2,        -(dt*q0)/2,         (dt*q1)/2, 0, 0, 0,  0,  0,  0,                              0,                              0,                              0;
                -dt*(gbZ/2 - gmZ/2),                                          -dt*(gbY/2 - gmY/2),                                           dt*(gbX/2 - gmX/2),                                                            1,         (dt*q2)/2,        -(dt*q1)/2,        -(dt*q0)/2, 0, 0, 0,  0,  0,  0,                              0,                              0,                              0;
                0,                                                            0,                                                            0,                                                            0, 1 - dt*lambdaGyro,                 0,                 0, 0, 0, 0,  0,  0,  0,                              0,                              0,                              0;
                0,                                                            0,                                                            0,                                                            0,                 0, 1 - dt*lambdaGyro,                 0, 0, 0, 0,  0,  0,  0,                              0,                              0,                              0;
                0,                                                            0,                                                            0,                                                            0,                 0,                 0, 1 - dt*lambdaGyro, 0, 0, 0,  0,  0,  0,                              0,                              0,                              0;
                0,                                                            0,                                                            0,                                                            0,                 0,                 0,                 0, 1, 0, 0, dt,  0,  0,                              0,                              0,                              0;
                0,                                                            0,                                                            0,                                                            0,                 0,                 0,                 0, 0, 1, 0,  0, dt,  0,                              0,                              0,                              0;
                0,                                                            0,                                                            0,                                                            0,                 0,                 0,                 0, 0, 0, 1,  0,  0, dt,                              0,                              0,                              0;
                dt*(2*q0*(abX - amX) - 2*q3*(abY - amY) + 2*q2*(abZ - amZ)),  dt*(2*q1*(abX - amX) + 2*q2*(abY - amY) + 2*q3*(abZ - amZ)),  dt*(2*q1*(abY - amY) - 2*q2*(abX - amX) + 2*q0*(abZ - amZ)), -dt*(2*q3*(abX - amX) + 2*q0*(abY - amY) - 2*q1*(abZ - amZ)),                 0,                 0,                 0, 0, 0, 0,  1,  0,  0, dt*(q0^2 + q1^2 - q2^2 - q3^2),        -dt*(2*q0*q3 - 2*q1*q2),         dt*(2*q0*q2 + 2*q1*q3);
                dt*(2*q3*(abX - amX) + 2*q0*(abY - amY) - 2*q1*(abZ - amZ)), -dt*(2*q1*(abY - amY) - 2*q2*(abX - amX) + 2*q0*(abZ - amZ)),  dt*(2*q1*(abX - amX) + 2*q2*(abY - amY) + 2*q3*(abZ - amZ)),  dt*(2*q0*(abX - amX) - 2*q3*(abY - amY) + 2*q2*(abZ - amZ)),                 0,                 0,                 0, 0, 0, 0,  0,  1,  0,         dt*(2*q0*q3 + 2*q1*q2), dt*(q0^2 - q1^2 + q2^2 - q3^2),        -dt*(2*q0*q1 - 2*q2*q3);
                dt*(2*q1*(abY - amY) - 2*q2*(abX - amX) + 2*q0*(abZ - amZ)),  dt*(2*q3*(abX - amX) + 2*q0*(abY - amY) - 2*q1*(abZ - amZ)), -dt*(2*q0*(abX - amX) - 2*q3*(abY - amY) + 2*q2*(abZ - amZ)),  dt*(2*q1*(abX - amX) + 2*q2*(abY - amY) + 2*q3*(abZ - amZ)),                 0,                 0,                 0, 0, 0, 0,  0,  0,  1,        -dt*(2*q0*q2 - 2*q1*q3),         dt*(2*q0*q1 + 2*q2*q3), dt*(q0^2 - q1^2 - q2^2 + q3^2);
                0,                                                            0,                                                            0,                                                            0,                 0,                 0,                 0, 0, 0, 0,  0,  0,  0,             1 - dt*lambdaAccel,                              0,                              0;
                0,                                                            0,                                                            0,                                                            0,                 0,                 0,                 0, 0, 0, 0,  0,  0,  0,                              0,             1 - dt*lambdaAccel,                              0;
                0,                                                            0,                                                            0,                                                            0,                 0,                 0,                 0, 0, 0, 0,  0,  0,  0,                              0,                              0,             1 - dt*lambdaAccel;
                ];
        end