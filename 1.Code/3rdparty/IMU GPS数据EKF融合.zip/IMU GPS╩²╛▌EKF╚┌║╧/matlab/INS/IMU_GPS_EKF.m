clear;
imuFs = 100;
gpsFs = 10;
imuSamplesPerGPS = (imuFs/gpsFs);
load trajData0.mat;
%% fusion gps imu data
% 创建数据融合对象
gndFusion = insfilterNonholonomic('ReferenceFrame', 'ENU', ...
    'IMUSampleRate', imuFs, ...
    'ReferenceLocation', localOrigin, ...
    'DecimationFactor', 100000);
% 初始化状态
gndFusion.State(1:4) = compact(initialAtt).';
gndFusion.State(5:7) = [0, 0, 0];%imu.Gyroscope.ConstantBias;
gndFusion.State(8:10) = initialPos.';
gndFusion.State(11:13) = initialVel.';
gndFusion.State(14:16) = [0, 0, 0];%imu.Accelerometer.ConstantBias;
Rpos = 1; % gps.HorizontalPositionAccuracy.^2;
gndFusion.ZeroVelocityConstraintNoise = 1e-2;
gndFusion.GyroscopeNoise = 4e-6;
gndFusion.GyroscopeBiasNoise = 4e-14;
gndFusion.AccelerometerNoise = 4.8e-2;
gndFusion.AccelerometerBiasNoise = 4e-14;
gndFusion.StateCovariance = 1e-9*ones(16);
lenGPSData = size(llas, 1);
lenIMUData = size(accelDatas, 1);
cnt = 0;
estPositions = [];
% 用于不更新GPS数据对比
estPositions2 = [];
gndFusion2 = gndFusion.copy();
gpsPoss = [];
for iGPS = 1:lenGPSData
    for iIMU = 1:imuSamplesPerGPS
        % 预测
        cnt = cnt + 1;
        accelData = accelDatas(cnt, :);
        gyroData  = gyroDatas(cnt, :);
        predict(gndFusion, accelData, gyroData);
        predict(gndFusion2, accelData, gyroData);
        [estPosition, ~] = pose(gndFusion);
        [estPosition2, ~] = pose(gndFusion2);
        estPositions = [estPositions; estPosition];
        estPositions2 = [estPositions2; estPosition2];
    end
    % 更新
    lla = llas(iGPS,:);
    fusegps(gndFusion, lla, Rpos);
    gpsPos = fusion.internal.frames.lla2enu(lla, localOrigin).';
    gpsPoss = [gpsPoss; gpsPos.'];  
end
% 绘图
subplot(2,1,1)
hold on;
plot(truePositions(:,1),truePositions(:,2), 'r.')
plot(estPositions(:,1),estPositions(:,2), 'b.')
axis equal;
title('EKF fusion')
sub2 = subplot(2,1,2);
hold on;
plot(gpsPoss(:,1), gpsPoss(:,2), 'g*','DisplayName','GPS data')
plot(truePositions(:,1),truePositions(:,2), 'r.','DisplayName','groundTruth')
hold on;
plot(estPositions2(:,1),estPositions2(:,2), 'b.','DisplayName','IMU predict data')
axis equal;
title('predict data and measured data')
legend(sub2,'show');