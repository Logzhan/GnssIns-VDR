function [x, P, innov, innovCov] = correctEqnFcn(x, P, h, H, z, R)
            innovCov = H*P*(H.') + R;
            W = P*(H.') / innovCov;
            
            innov = z - h;
            x = x + W*(innov);
            P = P - W*H*P;
            x = repairQuaternionFcn(x);
            
            % Make the innovation a row vector to match the measurement shape
            innov = reshape(innov, 1,[]);

        end