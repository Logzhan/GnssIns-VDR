function P = predictCovEqnFcn(P, F, U, G)
            Q = G*U*(G.');
            P = F*P*(F.') + Q;
        end