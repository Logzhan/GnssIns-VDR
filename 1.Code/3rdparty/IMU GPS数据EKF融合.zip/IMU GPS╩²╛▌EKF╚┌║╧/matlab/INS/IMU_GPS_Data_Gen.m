clear;
% IMU数据频率
imuFs = 100;
% GPS数据频率
gpsFs = 10;
% 初始位置
localOrigin = [0 0 0];
% IMU GPS频率比
imuSamplesPerGPS = (imuFs/gpsFs);
% 得到仿真车辆路点
[t, position, orientation] = GetWayPoints1();
% 得到仿真车辆轨迹
groundTruth = waypointTrajectory('SampleRate', imuFs, ...
    'Waypoints', position, ...
    'TimeOfArrival', t, ...
    'Orientation', orientation);
% 随机数生成器初始化
rng('default');
% GPS仿真模型
gps = gpsSensor('UpdateRate', gpsFs, 'ReferenceFrame', 'ENU');
gps.ReferenceLocation = localOrigin;
gps.DecayFactor = 0.5;                % Random walk noise parameter 
gps.HorizontalPositionAccuracy = 1.0;   
gps.VerticalPositionAccuracy =  1.0;
gps.VelocityAccuracy = 0.1;
% IMU仿真模型
imu = imuSensor('accel-gyro', ...
    'ReferenceFrame', 'ENU', 'SampleRate', imuFs);
% Accelerometer
imu.Accelerometer.MeasurementRange =  19.6133;
imu.Accelerometer.Resolution = 0.0023928;
imu.Accelerometer.NoiseDensity = 0.0012356*10;
% Gyroscope
imu.Gyroscope.MeasurementRange = deg2rad(250);
imu.Gyroscope.Resolution = deg2rad(0.0625);
imu.Gyroscope.NoiseDensity = deg2rad(0.025*10);

% 初始化
[initialPos, initialAtt, initialVel] = groundTruth();
reset(groundTruth);
% 仿真时间
totalSimTime = t(end);
% gps数据采样点数目
numsamples = floor(min(t(end), totalSimTime) * gpsFs);
% 数据记录
idx = 0;
truePositions = [];
accelDatas = [];
gyroDatas = [];
trueAngVels = [];
accelDatas = [];
llas = [];
dT_IMU = 1/imuFs;
dT_GPS = 1/gpsFs;
timeIMU = 0.0;
timeGPS = 0.0;
% 仿真循环
for sampleIdx = 1:numsamples
    for i = 1:imuSamplesPerGPS
        if ~isDone(groundTruth)
            idx = idx + 1;
            % 得到真值数据
            [truePosition, trueOrientation, ...
                trueVel, trueAcc, trueAngVel] = groundTruth();
            % 保存真值数据
            truePositions = [truePositions; truePosition];
            % 得到IMU数据
            [accelData, gyroData] = imu(trueAcc, trueAngVel, ...
                trueOrientation);
            % 保存IMU数据
            trueAngVels = [trueAngVels; trueAngVel];
            accelDatas = [accelDatas; accelData];
            gyroDatas  = [gyroDatas; gyroData];
            timeIMU = timeIMU + dT_IMU;
        end
    end   
    if ~isDone(groundTruth)
        % 得到GPS数据
        [lla, gpsVel] = gps(truePosition, trueVel);
        % 保存GPS数据
        llas = [llas; lla];
        timeGPS = timeGPS + dT_GPS;
    end
end
save('trajData5.mat', 'localOrigin','truePositions','accelDatas','gyroDatas','llas','initialAtt','initialPos','initialVel');
