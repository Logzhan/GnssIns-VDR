clear;
imuFs = 100;
gpsFs = 10;
imuSamplesPerGPS = (imuFs/gpsFs);
load trajData2.mat;
% 初始化状态
gndFusion_State = zeros(16,1);
gndFusion_State(1:4) = compact(initialAtt).';
gndFusion_State(5:7) = [0, 0, 0];%imu.Gyroscope.ConstantBias;
gndFusion_State(8:10) = initialPos.';
gndFusion_State(11:13) = initialVel.';
gndFusion_State(14:16) = [0, 0, 0];%imu.Accelerometer.ConstantBias;
gndFusion_State2 = gndFusion_State;
Rpos = 1; % gps.HorizontalPositionAccuracy.^2;
accelBiasDecayFactor = 0.9999;
gyroBiasDecayFactor = 0.999;
gndFusion_ZeroVelocityConstraintNoise = 1e-2;
gndFusion_GyroscopeNoise = 4e-6;
gndFusion_GyroscopeBiasNoise = 4e-14;
gndFusion_AccelerometerNoise = 4.8e-2;
gndFusion_AccelerometerBiasNoise = 4e-14;
gndFusion_StateCovariance = 1e-9*ones(16);
lenGPSData = size(llas, 1);
lenIMUData = size(accelDatas, 1);
cnt = 0;
estPositions = [];
% 用于不更新GPS数据对比
estPositions2 = [];
gpsPoss = [];
dt = 1/imuFs;
for iGPS = 1:lenGPSData
    for iIMU = 1:imuSamplesPerGPS
        % 预测
        cnt = cnt + 1;
        accelData = accelDatas(cnt, :);
        gyroData  = gyroDatas(cnt, :);
        accelMeas = accelData;
        gyroMeas  = gyroData;
        gndFusion_State = IMUstateTranTcn(gndFusion_State, dt, ...
            accelMeas, gyroMeas, ...
            accelBiasDecayFactor, gyroBiasDecayFactor);
        gndFusion_State2 = IMUstateTranTcn(gndFusion_State2, dt, ...
            accelMeas, gyroMeas, ...
            accelBiasDecayFactor, gyroBiasDecayFactor);
        estPositions2 = [estPositions2; gndFusion_State2(8:10)'];
        F = IMUstateTransitionJacobianFcn(gndFusion_State, dt, ...
            accelMeas, gyroMeas, ...
            accelBiasDecayFactor, gyroBiasDecayFactor);
        G = IMUnoiseJacobianFcn(gndFusion_State, dt);
        U = IMUnoiseCovariance();
        gndFusion_StateCovariance = predictCovEqnFcn(gndFusion_StateCovariance, F, U, G);
    end
    % 更新
        h = GPSPositionmeasurementFcn(gndFusion_State);
        H = GPSPositionmeasurementJacobianFcn(gndFusion_State);
        gpsPos = llas(iGPS,:);
        [p1,p2,~] = gnsstoxy(gpsPos(2),gpsPos(1));
        pos = [p1,p2,0]';
        R = Rpos*eye(3);
        P = gndFusion_StateCovariance;
        [gndFusion_State, gndFusion_StateCovariance, innov, iCov] = correctEqnFcn(gndFusion_State, ...
                P, h, H, pos, R);
        gpsPoss = [gpsPoss; pos.'];
        estPosition = gndFusion_State(8:10)';
        estPositions = [estPositions; estPosition];
end
% 绘图
subplot(2,1,1)
hold on;
plot(truePositions(:,1),truePositions(:,2), 'r.')
plot(estPositions(:,1),estPositions(:,2), 'b.')
axis equal;
title('EKF fusion')
sub2 = subplot(2,1,2);
hold on;
plot(gpsPoss(:,1), gpsPoss(:,2), 'g*','DisplayName','GPS data')
plot(truePositions(:,1),truePositions(:,2), 'r.','DisplayName','groundTruth')
hold on;
plot(estPositions2(:,1),estPositions2(:,2), 'b.','DisplayName','IMU predict data')
axis equal;
title('predict data and measured data')
legend(sub2,'show');