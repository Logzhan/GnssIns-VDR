function x = repairQuaternionFcn(x)
            % Normalize quaternion and enforce a positive angle of
            % rotation. Avoid constructing a quaternion here. Just do the
            % math inline.

            % Used cached OrientationIdx
%             idx = obj.OrientationIdx;
            qparts = x(1:4);
            n = sqrt(sum(qparts.^2));
            qparts = qparts./n;
            if qparts(1) < 0
                x(1:4) = -qparts;
            else
                x(1:4) = qparts;
            end
        end