subplot(2,3,1)
clear;
load trajData1.mat;
plot(truePositions(:,1),truePositions(:,2), 'b.');
axis equal;

subplot(2,3,2)
clear;
load trajData2.mat;
plot(truePositions(:,1),truePositions(:,2), 'b.');
axis equal;

subplot(2,3,3)
clear;
load trajData3.mat;
plot(truePositions(:,1),truePositions(:,2), 'b.');
axis equal;

subplot(2,3,4)
clear;
load trajData4.mat;
plot(truePositions(:,1),truePositions(:,2), 'b.');
axis equal;

subplot(2,3,5)
clear;
load trajData5.mat;
plot(truePositions(:,1),truePositions(:,2), 'b.');
axis equal;

subplot(2,3,6)
clear;
load trajData0.mat;
plot(truePositions(:,1),truePositions(:,2), 'b.');
axis equal;