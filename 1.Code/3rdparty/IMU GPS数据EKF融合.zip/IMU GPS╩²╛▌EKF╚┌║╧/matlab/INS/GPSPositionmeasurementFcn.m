function h = GPSPositionmeasurementFcn(x)
            pos = x(8:10);
            h = pos;
end