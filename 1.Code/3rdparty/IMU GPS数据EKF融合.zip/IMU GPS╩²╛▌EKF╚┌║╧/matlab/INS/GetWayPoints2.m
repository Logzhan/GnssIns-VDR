function [t, position, orientation] = GetWayPoints2()
r = 60; % (m)
speed = 5.0; % (m/s)
center = [0, 0]; % (m)
initialYaw = 90; % (degrees)
numRevs = 0.8;
revTime = 2*pi*r / speed;
theta = (0:pi/20:2*pi*numRevs).';
t = linspace(0, revTime*numRevs, numel(theta)).';
x = r .* cos(theta) + center(1);
y = r .* sin(theta) + center(2);
z = zeros(size(x));
position = [x, y, z];
% Define orientation.
yaw = theta + deg2rad(initialYaw);
yaw = mod(yaw, 2*pi);
pitch = zeros(size(yaw));
roll = zeros(size(yaw));
orientation = quaternion([yaw, pitch, roll], 'euler', ...
    'ZYX', 'frame');
end