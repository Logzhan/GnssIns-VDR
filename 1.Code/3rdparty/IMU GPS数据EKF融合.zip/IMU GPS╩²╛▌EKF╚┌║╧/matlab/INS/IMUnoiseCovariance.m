function U = IMUnoiseCovariance()
            % Process noises.
            GyroscopeNoise = 4e-6*ones(1,3);
            GyroscopeBiasNoise = 4e-14*ones(1,3);
            AccelerometerNoise = 4.8e-2*ones(1,3);
            AccelerometerBiasNoise = 4e-14*ones(1,3);
            gyroVar = diag(GyroscopeNoise);
            gyroBiasVar = diag(GyroscopeBiasNoise);
            accelVar = diag(AccelerometerNoise);
            accelBiasVar = diag(AccelerometerBiasNoise);
            U = blkdiag(gyroVar, gyroBiasVar, accelVar, accelBiasVar);
        end