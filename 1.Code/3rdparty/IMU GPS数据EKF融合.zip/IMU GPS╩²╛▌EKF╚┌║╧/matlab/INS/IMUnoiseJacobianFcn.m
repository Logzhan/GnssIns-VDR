function G = IMUnoiseJacobianFcn(x, dt)
            %PROCESSNOISEJACOBIANFCN Compute jacobian for multiplicative process noise
            %   The process noise Jacobian G for state vector x and multiplicative
            %   process noise w is L* W * (L.') where
            %       L = jacobian of update function f with respect to drive inputs
            %       W = covariance matrix of multiplicative process noise w.
            
            q0 = x(1);
            q1 = x(2);
            q2 = x(3);
            q3 = x(4);
            gbX = x(5); %#ok<NASGU>
            gbY = x(6); %#ok<NASGU>
            gbZ = x(7); %#ok<NASGU>
            pn = x(8); %#ok<NASGU>
            pe = x(9); %#ok<NASGU>
            pd = x(10); %#ok<NASGU>
            vn = x(11); %#ok<NASGU>
            ve = x(12); %#ok<NASGU>
            vd = x(13); %#ok<NASGU>
            abX = x(14); %#ok<NASGU>
            abY = x(15); %#ok<NASGU>
            abZ = x(16); %#ok<NASGU>
            
            G = ...
                [
                -(dt*q1)/2, -(dt*q2)/2, -(dt*q3)/2, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                (dt*q0)/2, -(dt*q3)/2,  (dt*q2)/2, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                (dt*q3)/2,  (dt*q0)/2, -(dt*q1)/2, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                -(dt*q2)/2,  (dt*q1)/2,  (dt*q0)/2, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                0,          0,          0, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                0,          0,          0, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                0,          0,          0, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                0,          0,          0, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                0,          0,          0, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                0,          0,          0, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                0,          0,          0, 0, 0, 0, -dt*(q0^2 + q1^2 - q2^2 - q3^2),          dt*(2*q0*q3 - 2*q1*q2),         -dt*(2*q0*q2 + 2*q1*q3), 0, 0, 0;
                0,          0,          0, 0, 0, 0,         -dt*(2*q0*q3 + 2*q1*q2), -dt*(q0^2 - q1^2 + q2^2 - q3^2),          dt*(2*q0*q1 - 2*q2*q3), 0, 0, 0;
                0,          0,          0, 0, 0, 0,          dt*(2*q0*q2 - 2*q1*q3),         -dt*(2*q0*q1 + 2*q2*q3), -dt*(q0^2 - q1^2 - q2^2 + q3^2), 0, 0, 0;
                0,          0,          0, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                0,          0,          0, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                0,          0,          0, 0, 0, 0,                               0,                               0,                               0, 0, 0, 0;
                ];
        end