function [t, position, orientation] = GetWayPoints1()
[s, x, y, phi, curve] = importroadfile('road5.txt');
speed = 10;
t = s/speed;
z = x * 0;
position = [x, y, z];
yaw = phi;
pitch = zeros(size(yaw));
roll = zeros(size(yaw));
orientation = quaternion([yaw, pitch, roll], 'euler', ...
    'ZYX', 'frame');
end