function x = IMUstateTranTcn(x, dt, accelMeas, gyroMeas, accelBiasDecayFactor, gyroBiasDecayFactor)
            %STATETRANSITIONFCN new filter states based on current IMU data
            %   Predict forward the state estimate one time sample, based on control
            %   inputs:
            %       new gyroscope readings, and
            %       new accelerometer readings.
            
            q0 = x(1);
            q1 = x(2);
            q2 = x(3);
            q3 = x(4);
            gbX = x(5);
            gbY = x(6);
            gbZ = x(7);
            pn = x(8);
            pe = x(9);
            pd = x(10);
            vn = x(11);
            ve = x(12);
            vd = x(13);
            abX = x(14);
            abY = x(15);
            abZ = x(16);
            
            amX = accelMeas(1);
            amY = accelMeas(2);
            amZ = accelMeas(3);
            gmX = gyroMeas(1);
            gmY = gyroMeas(2);
            gmZ = gyroMeas(3);
            
            lambdaAccel = 1-accelBiasDecayFactor;
            lambdaGyro = 1-gyroBiasDecayFactor;
            
            grav = zeros(1,3, 'like', x);
            grav(3) = 9.81;
            gravX = grav(1);
            gravY = grav(2);
            gravZ = grav(3);
            
            % State update equation
            % Orientation is updated below. This line updates position, velocity, and
            % sensor biases.
            %
            % x(1:4) - pre-allocated placeholders of the current quaternion parts.
            % x(5:7) - gyroscope bias update equation. The new gyroscope bias is the
            %    current bias times the decay factor filter parameter.
            % x(8:10) - position update equation. The new position is
            %    the current position plus the effect of the current velocity.
            % x(11:13) - velocity update equation. The new velocity is
            %    the current velocity plus the current acceleration estimate times the
            %        sample time.
            %        The current acceleration estimate is the accelerometer measurement
            %        minus accelerometer bias, rotated to the global frame, then
            %        subtracted by the gravity vector's effect.
            % x(14:16) - accelerometer bias update equation. The new accelerometer bias
            %    is the current bias times the decay factor filter parameter.
            %
            % In all of the above, a "plus white noise" is assumed by the Extended
            % Kalman Filter formulation. So, for example, the new position
            % is the previous position plus the effect of the current velocity plus
            % white noise.
            x = ...
                [
                q0 + dt*q1*(gbX/2 - gmX/2) + dt*q2*(gbY/2 - gmY/2) + dt*q3*(gbZ/2 - gmZ/2);
                q1 - dt*q0*(gbX/2 - gmX/2) + dt*q3*(gbY/2 - gmY/2) - dt*q2*(gbZ/2 - gmZ/2);
                q2 - dt*q3*(gbX/2 - gmX/2) - dt*q0*(gbY/2 - gmY/2) + dt*q1*(gbZ/2 - gmZ/2);
                q3 + dt*q2*(gbX/2 - gmX/2) - dt*q1*(gbY/2 - gmY/2) - dt*q0*(gbZ/2 - gmZ/2);
                -gbX*(dt*lambdaGyro - 1);
                -gbY*(dt*lambdaGyro - 1);
                -gbZ*(dt*lambdaGyro - 1);
                pn + dt*vn;
                pe + dt*ve;
                pd + dt*vd;
                vn + dt*(q0*(q0*(abX - amX) - q3*(abY - amY) + q2*(abZ - amZ)) - gravX + q2*(q1*(abY - amY) - q2*(abX - amX) + q0*(abZ - amZ)) + q1*(q1*(abX - amX) + q2*(abY - amY) + q3*(abZ - amZ)) - q3*(q3*(abX - amX) + q0*(abY - amY) - q1*(abZ - amZ)));
                ve + dt*(q0*(q3*(abX - amX) + q0*(abY - amY) - q1*(abZ - amZ)) - gravY - q1*(q1*(abY - amY) - q2*(abX - amX) + q0*(abZ - amZ)) + q2*(q1*(abX - amX) + q2*(abY - amY) + q3*(abZ - amZ)) + q3*(q0*(abX - amX) - q3*(abY - amY) + q2*(abZ - amZ)));
                vd + dt*(q0*(q1*(abY - amY) - q2*(abX - amX) + q0*(abZ - amZ)) - gravZ + q1*(q3*(abX - amX) + q0*(abY - amY) - q1*(abZ - amZ)) - q2*(q0*(abX - amX) - q3*(abY - amY) + q2*(abZ - amZ)) + q3*(q1*(abX - amX) + q2*(abY - amY) + q3*(abZ - amZ)));
                -abX*(dt*lambdaAccel - 1);
                -abY*(dt*lambdaAccel - 1);
                -abZ*(dt*lambdaAccel - 1);
                ];
%             x = repairQuaternionFcn(x);
        end