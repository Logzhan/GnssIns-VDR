function [x,y,f] = gnsstoxy(lon,lat)
x = lon*20037508.342789/180;
y = log(tan((90+lat)*pi/360))/(pi/180)*20037508.342789/180;
f = sec(lat/180*pi);