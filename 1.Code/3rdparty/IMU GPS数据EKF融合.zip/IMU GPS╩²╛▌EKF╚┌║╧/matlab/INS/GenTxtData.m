clear;
load trajData1.mat;
fid = fopen('trajData1.txt', 'w');
fprintf(fid, '%s\n', 'initialAtt');
fprintf(fid, '%s\n', num2str(compact(initialAtt)));
fprintf(fid, '%s\n', 'initialPos');
fprintf(fid, '%s\n', num2str((initialPos)));
fprintf(fid, '%s\n', 'initialVel');
fprintf(fid, '%s\n', num2str((initialVel)));
fprintf(fid, '%s\n', 'truePositions');
for i = 1:size(truePositions, 1)
    fprintf(fid, '%s\n', num2str(truePositions(i, :)));
end
fprintf(fid, '%s\n', 'accelDatas');
for i = 1:size(accelDatas, 1)
    fprintf(fid, '%s\n', num2str(accelDatas(i, :)));
end
fprintf(fid, '%s\n', 'gyroDatas');
for i = 1:size(gyroDatas, 1)
    fprintf(fid, '%s\n', num2str(gyroDatas(i, :)));
end
fprintf(fid, '%s\n', 'llas');
for i = 1:size(llas, 1)
    fprintf(fid, '%s\n', num2str(llas(i, :)));
end
fclose(fid);